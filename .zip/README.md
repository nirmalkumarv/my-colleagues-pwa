# my-colleagues-pwa

My Colleagues is a Simple Progressive Web Application which helps anyone to easily access their colleague basic information even in offline ode.

Basic information

Name
Department
Extension

SkypeId

Note : Due to Privacy, We are not using Photo,EmailId or Contact No here.